<strong><?php _e('Blocksy - The Most Innovative & Lightning Fast WordPress Theme', $this->plugin_slug); ?></strong>

<br /><br />
<?php _e('A blazing fast and lightweight WordPress theme built with the latest web technologies. It was built with the Gutenberg editor in mind and has a lot of options that makes it extendable and customizable.', $this->plugin_slug); ?>
<br /><br />

<a class="button button-primary" href="<?php echo esc_url(wpmm_get_utmized_url('https://creativethemes.com/blocksy/', array('source' => 'notice'))); ?>" target="_blank">
    <?php _e('Download for Free Now', $this->plugin_slug); ?>
</a>